function y = radtodeg(x)
y = x * 180/pi;