function y = degtorad(x)
y = x * pi/180;